import React from 'react';
import { Switch } from 'react-router-dom';
import Home from 'app/modules/home/home';
import ErrorBoundaryRoute from 'app/shared/error/error-boundary-route';
import PageNotFound from 'app/shared/error/page-not-found';

const Routes = () => {
  return (
    <Switch>
      {/* <ErrorBoundaryRoute path="/login" component={Login} />
        <ErrorBoundaryRoute path="/account/activate/:key?" component={Activate} /> */}
      <ErrorBoundaryRoute path="/" exact component={Home} />
      <ErrorBoundaryRoute component={PageNotFound} />
    </Switch>
  );
};

export default Routes;

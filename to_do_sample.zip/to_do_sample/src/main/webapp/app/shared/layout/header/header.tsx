import React, { useState } from 'react';
import { useAppDispatch, useAppSelector } from 'app/config/store';
import { setQuerySearch } from 'app/modules/home/home.reducer'

const Header = () => {
  const dispatch = useAppDispatch();
  const [vSearch, setVSearch] = useState("")

  const handleSetSearch = () => { dispatch(setQuerySearch(vSearch)) }
  return (
    <nav className="navbar navbar-light navbar-expand bg-white shadow mb-4 topbar static-top">
      <div className="container-fluid">
        <button className="btn btn-link d-md-none rounded-circle mr-3" id="sidebarToggleTop" type="button">
          <i className="fas fa-bars" />
        </button>
        <form className="form-inline d-none d-sm-inline-block mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
          <div className="input-group">
            <input className="bg-light form-control border-0 small" type="text" placeholder="Search for ..." onChange={(v) => setVSearch(v.target.value)} />
            <div className="input-group-append">
              <button className="btn btn-primary py-0" type="button" onClick={() => { handleSetSearch() }}>
                <i className="fas fa-search" />
              </button>
            </div>
          </div>
        </form>
        <a className="btn btn-primary btn-sm d-none d-sm-inline-block" >
          <i className="fas fa-plus fa-sm text-white-50" />
          &nbsp;Add New
        </a>
        <ul className="navbar-nav flex-nowrap">
          <li className="nav-item dropdown no-arrow mx-1">
            <div className="nav-item dropdown no-arrow">
              <a className="dropdown-toggle nav-link" aria-expanded="false" data-toggle="dropdown" >
                <span className="badge badge-danger badge-counter">1+</span>
                <i className="fas fa-bell fa-fw" />
              </a>
              <div className="dropdown-menu dropdown-menu-right dropdown-list animated--grow-in">
                <h6 className="dropdown-header">alerts center</h6>
                <a className="dropdown-item d-flex align-items-center" >
                  <div className="mr-3">
                    <div className="bg-warning icon-circle"><i className="fas fa-exclamation-triangle text-white"></i></div>
                  </div>
                  <div><span className="small text-gray-500">July 11, 2022</span>
                    <p>This color is exist. Please choose other color!</p>
                  </div>
                </a>
                <a className="dropdown-item text-center small text-gray-500" >Show All Alerts</a>
              </div>
            </div>
          </li>
          <div className="d-none d-sm-block topbar-divider" />
          <li className="nav-item dropdown no-arrow">
            <div className="nav-item dropdown no-arrow">
              <a className="dropdown-toggle nav-link" aria-expanded="false" data-toggle="dropdown" >
                <span className="d-none d-lg-inline mr-2 text-gray-600 small">Dong</span>
                <img className="border rounded-circle img-profile" />
              </a>
              <div className="dropdown-menu shadow dropdown-menu-right animated--grow-in">
                <a className="dropdown-item" >
                  <i className="fas fa-user fa-sm fa-fw mr-2 text-gray-400" />
                  &nbsp;Profile
                </a>
                <a className="dropdown-item" >
                  <i className="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400" />
                  &nbsp;Settings
                </a>
                <a className="dropdown-item" >
                  <i className="fas fa-list fa-sm fa-fw mr-2 text-gray-400" />
                  &nbsp;Activity log
                </a>
                <div className="dropdown-divider" />
                <a className="dropdown-item" >
                  <i className="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400" />
                  &nbsp;Logout
                </a>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Header;

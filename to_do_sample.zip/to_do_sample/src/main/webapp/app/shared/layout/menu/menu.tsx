import React, { useLayoutEffect, useState } from 'react';
import MenuItem from 'app/shared/layout/menu/menu-item';


const Menu = () => {
  const [menuOpen, setMenuOpen] = useState(true);
  const menuItem = [
    {
      icon: "table",
      to: "home",
      id: "home",
      name: "Home"
    },
    {
      icon: "cog",
      to: "setting",
      id: "setting",
      name: "Setting"
    }
  ]
  useLayoutEffect(() => {
    if (!menuOpen) {
      !document.body.classList.contains("sidebar-toggled") && document.body.classList.add("sidebar-toggled")
      !document.getElementById("menu-bar").classList.contains("toggled") && document.getElementById("menu-bar").classList.add("toggled")
    } else {
      document.body.classList.contains("sidebar-toggled") && document.body.classList.remove("sidebar-toggled")
      document.getElementById("menu-bar").classList.contains("toggled") && document.getElementById("menu-bar").classList.remove("toggled")
    }

  }, [menuOpen])

  return (
    <nav id="menu-bar" className="navbar navbar-dark align-items-start sidebar sidebar-dark accordion bg-gradient-primary p-0">
      <div className="container-fluid d-flex flex-column p-0">
        <a className="navbar-brand d-flex justify-content-center align-items-center sidebar-brand m-0" >
          <div className="sidebar-brand-icon rotate-n-15">
            <i className="fas fa-laugh-wink" />
          </div>
          <div className="sidebar-brand-text mx-3">
            <span>To Do</span>
          </div>
        </a>
        <div className="sidebar-divider my-0">
          <ul className="navbar-nav text-light" id="accordionSidebar">
            {
              menuItem.map((e) => {
                return (<>
                  <MenuItem id={e.id} icon={e.icon} to={e.to} name={e.name} key={e.id} /></>
                )
              })
            }
          </ul>
        </div>
        <div className="text-center d-none d-md-inline">
          <button className="btn rounded-circle border-0" id="sidebarToggle" type="button" onClick={() => setMenuOpen(!menuOpen)} />
        </div>
      </div>
    </nav>
  );
};

export default Menu;

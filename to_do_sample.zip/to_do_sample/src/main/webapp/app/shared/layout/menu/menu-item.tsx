import React from 'react';
import { Link } from 'react-router-dom';

export interface IMenuItem {
  icon: string;
  to: string;
  name: string;
  id?: string;
}

export default class MenuItem extends React.Component<IMenuItem> {
  render() {
    const { to, icon, id, name } = this.props;

    return (
      <li className="nav-item">
        <Link className="nav-link" to={to} id={id}>
          <i className={"fas fa-" + icon} />
          <span>{name}</span></Link>
      </li>
    );
  }
}

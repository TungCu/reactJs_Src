import _ from 'lodash';
import React, { useLayoutEffect, useEffect, useState } from 'react';

export interface IPaging {
  allRecord: number,
  indexPage: number,
  limitPage: number,
  setIndexPage: (index: number) => void
}

const Paging = (props: IPaging) => {
  const maxPage = props.allRecord % props.limitPage !== 0 ? Math.floor(props.allRecord / props.limitPage) + 1 : props.allRecord / props.limitPage;
  const [displayPage, setDisplayPage] = useState([])
  const [indexDisplay, setIndexDisplay] = useState(null)
  useEffect(() => {
    const lstPage = [];
    const lstDisplayPage = maxPage % 2 !== 0 ? Math.floor(maxPage / 2) + 1 : maxPage / 2;
    for (let i = 1; i <= lstDisplayPage; i++) {
      if (2 * i <= maxPage) {
        lstPage.push([i * 2 - 1, i * 2])
      } else {
        lstPage.push([i * 2 - 1])
      }
    }

    setIndexDisplay(lstPage.findIndex(e => e.includes(props.indexPage + 1)));
    setDisplayPage(lstPage)
  }, [props.allRecord, props.indexPage, props.limitPage])

  if (displayPage.length === 0) {
    return <></>
  } else {
    return (
      <nav className="d-lg-flex justify-content-lg-end dataTables_paginate paging_simple_numbers">
        <ul className="pagination">
          <li id={"nav-back"} className={`page-item ${props.indexPage + 1 === 1 ? "disabled" : ""}`}>
            <a className="page-link" aria-label="Previous" onClick={() => { setIndexDisplay(indexDisplay - 1); props.setIndexPage(_.get(displayPage, indexDisplay - 1)[0]) }}>
              <span aria-hidden="true">«</span>
            </a>
          </li>

          {!_.get(displayPage, 0).includes(props.indexPage + 1) && <li className="page-item"><a className="page-link" >...</a></li>}

          {_.get(displayPage, indexDisplay)[0] && <li className={`page-item ${_.get(displayPage, indexDisplay)[0] === props.indexPage + 1 ? 'active' : ""}`}><a className="page-link" onClick={() => { props.setIndexPage(_.get(displayPage, indexDisplay)[0]) }}>{_.get(displayPage, indexDisplay)[0]}</a></li>}
          {_.get(displayPage, indexDisplay)[1] && <li className={`page-item ${_.get(displayPage, indexDisplay)[1] === props.indexPage + 1 ? 'active' : ""}`}><a className="page-link" onClick={() => { props.setIndexPage(_.get(displayPage, indexDisplay)[1]) }}>{_.get(displayPage, indexDisplay)[1]}</a></li>}

          {!_.get(displayPage, displayPage.length - 1).includes(props.indexPage + 1) && <li className="page-item"><a className="page-link" >...</a></li>}

          <li id={"nav-next"} className={`page-item ${indexDisplay + 1 === displayPage.length ? "disabled" : ""}`}>
            <a className="page-link" aria-label="Next" onClick={() => { setIndexDisplay(indexDisplay + 1); props.setIndexPage(_.get(displayPage, indexDisplay + 1)[0]) }}>
              <span aria-hidden="true">»</span>
            </a>
          </li>
        </ul>
      </nav>
    );
  }

};

export default Paging;

import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { bindActionCreators } from 'redux';

import getStore from 'app/config/store';
import { saveSetting } from 'app/shared/reducers/authentication';
import ErrorBoundary from 'app/shared/error/error-boundary';
import AppComponent from 'app/app';
import axios from 'axios';
import _ from "lodash";

const store = getStore();

axios.get("http://localhost:3002/api/get-setting", {
  headers: {
    "Content-Type": "application/json"
  }
}).then(res => {
  if (res && res.data && res.data.data) {
    const actionsSaveSetting = bindActionCreators({ saveSetting }, store.dispatch);
    actionsSaveSetting.saveSetting(
      _.get(res.data.data, "mode"),
      _.get(res.data.data, "limit_record"),
      _.get(res.data.data, "date_format"),
      _.get(res.data.data, "color_doing"),
      _.get(res.data.data, "color_not_yet"),
      _.get(res.data.data, "color_done"),
      _.get(res.data.data, "noti_time")
    );
  }
})

const rootEl = document.getElementById('wrapper');

const render = Component =>
  // eslint-disable-next-line react/no-render-return-value
  ReactDOM.render(
    <ErrorBoundary>
      <Provider store={store}>
        <Component />
      </Provider>
    </ErrorBoundary>,
    rootEl
  );

render(AppComponent);

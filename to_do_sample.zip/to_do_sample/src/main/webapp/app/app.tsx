import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';

import ErrorBoundary from 'app/shared/error/error-boundary';
import Menu from 'app/shared/layout/menu/menu';
import Header from 'app/shared/layout/header/header';
import AppRoutes from 'app/routes';

const baseHref = document.querySelector('base').getAttribute('href').replace(/\/$/, '');

export const App = () => {
  return (
    <Router basename={baseHref}>
      <Menu />
      <div className="d-flex flex-column" id="content-wrapper">
        <div id="content">
          <ErrorBoundary>
            <Header />
            <AppRoutes />
          </ErrorBoundary>
        </div>
      </div>
    </Router>
  );
};

export default App;

/* eslint-disable no-console */
import { motion } from "framer-motion";

import React, { useEffect, useState } from 'react';

import { useAppSelector } from 'app/config/store';
import _ from "lodash";
import { Paging as P } from "./home";
import Paging from "app/shared/layout/paging/paging";

export interface ITable {
  data: any,
  lstChecked: any,
  handleSelect?: (d: any) => void,
  paging: P,
  setIndexPage: (index: number) => void,
  selectAll: () => void,
  selectedAllData: boolean
}

export const Table = (props: ITable) => {
  const setting = useAppSelector(state => state.authentication);
  console.log(setting);

  const getColor = (status) => {
    switch (status) {
      case "Not Yet":
        return setting.colorNotYet
      case "Doing":
        return setting.colorDoing
      case "Done":
        return setting.colorDone
      default:
        break;
    }
  }

  if (props.data) {
    return (<>
      <div className="container-fluid">
        <div className="card shadow">
          <div className="card-body">
            <div className="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
              <table className="table my-0" id="dataTable">
                <thead>
                  <tr>
                    <th style={{ width: "3%" }}>
                      <div className="custom-control custom-checkbox" onClick={() => { props.selectAll && props.selectAll() }}>
                        <input className="custom-control-input"
                          type="checkbox"
                          id="all"
                          name="all"
                          value="all"
                          checked={props.selectedAllData}
                        />
                        <label className="custom-control-label" />
                      </div>
                    </th>
                    <th style={{ width: "3%" }}>Id</th>
                    <th style={{ width: "12%" }}>To do</th>
                    <th style={{ width: "42%" }}>Description</th>
                    <th style={{ width: "15%" }}>Date Reminder</th>
                    <th style={{ width: "15%" }}>Create Date</th>
                    <th style={{ width: "10%" }}>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    props.data && props.data.length > 0 && props.data.map((e, i) => {
                      return (<>
                        <tr style={{ color: getColor(e.status) }}>
                          <td style={{ width: "3%" }}>
                            <div className="custom-control custom-checkbox" onClick={() => { !props.selectedAllData && props.handleSelect && props.handleSelect(e) }}>
                              <input className="custom-control-input"
                                type="checkbox"
                                id={e.id}
                                name={e.id}
                                value={e.id}
                                disabled={props.selectedAllData}
                                checked={props.selectedAllData || props.lstChecked && Array.isArray(props.lstChecked) && !!props.lstChecked.find(ele => ele === e.id)}
                              />
                              <label className="custom-control-label" />
                            </div>
                          </td>
                          <td style={{ width: "3%" }}>{e.id}</td>
                          <td style={{ width: "12%" }}>{e.title}</td>
                          <td style={{ width: "42%" }}>{e.note}</td>
                          <td style={{ width: "15%" }}>{e.reminder_datetime}</td>
                          <td style={{ width: "15%" }}>{e.create_date}</td>
                          <td style={{ width: "10%" }}>{e.status}</td>
                        </tr>
                      </>)
                    })
                  }

                </tbody>
              </table>
            </div>
            <div className="row">
              <div className="col-md-6 align-self-center">
                <p id="dataTable_info" className="dataTables_info" role="status" aria-live="polite">
                  Showing {props.paging.indexPage * props.paging.limitPage + 1} to {(props.paging.indexPage + 1) * props.paging.limitPage > props.paging.count ? props.paging.count : (props.paging.indexPage + 1) * props.paging.limitPage} of {props.paging.count}
                </p>
              </div>
              <div className="col-md-6">

                <Paging
                  allRecord={props.paging.count}
                  limitPage={props.paging.limitPage}
                  indexPage={props.paging.indexPage}
                  setIndexPage={(index) => { props.setIndexPage(index) }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
    );
  } else {
    return <></>
  }
};

export default Table;

/* eslint-disable no-console */
import { motion } from "framer-motion";
import List from "./list";
import Table from "./table";
import React, { useEffect, useState, useLayoutEffect } from 'react';
import { useAppSelector } from 'app/config/store';
import axios from "axios";
import _ from "lodash";

export const TYPE_DISPLAY = {
  table: "Table",
  list: "List",
  card: "Card"
}

export interface Paging {
  limitPage: number,
  count: number,
  indexPage: number
}

export const Home = () => {
  const setting = useAppSelector(state => state.authentication);
  const home = useAppSelector(state => state.homeReducer);
  const [data, setData] = useState([]);
  const [offset, setOffset] = useState(1);
  const [limit, setLimit] = useState(setting.limit);
  const [lstChecked, setLstChecked] = useState([]);
  const [display, setDisplay] = useState(TYPE_DISPLAY.table);
  const [paging, setPaging] = useState<Paging>(null);
  const [selectedAll, setSelectedAll] = useState(false);


  const selectRecord = (record) => {
    let checkTmp = _.cloneDeep(lstChecked);
    if (lstChecked.includes(record.id)) {
      checkTmp = lstChecked.filter(e => e !== record.id);
    } else {
      checkTmp.push(record.id)
    }
    setLstChecked(checkTmp);
  }

  const selectAll = () => {
    setSelectedAll(!selectedAll);

    !selectedAll && setLstChecked([])
  }

  const getData = () => {
    axios.get(`http://localhost:3002/api/get-list-todo?q=${home.querySearch}&l=${limit}&o=${offset - 1}`, {
      headers: {
        "Content-Type": "application/json"
      }
    }).then(res => {
      if (res && res.data && res.data.data) {
        setData(res.data.data);
        setPaging({
          count: res.data.count,
          limitPage: limit,
          indexPage: offset - 1
        })
      }
    })
  }
  const changeMode = (id) => {
    setSelectedAll(false);
    setLstChecked([])
    setDisplay(id);
  }
  useLayoutEffect(() => {
    getData()
  }, [home.querySearch, offset, limit])

  useLayoutEffect(() => {
    setOffset(1)
    setSelectedAll(false);
    setLstChecked([])
  }, [home.querySearch])

  const renderDisplay = () => {

    if (_.isEmpty(data) || _.isEmpty(paging)) return <></>
    switch (display) {
      case TYPE_DISPLAY.list:
        return (<List
          data={data}
          lstChecked={lstChecked}
          handleSelect={selectRecord}
          paging={paging}
        />)
      case TYPE_DISPLAY.card:
        return (<Table
          data={data}
          lstChecked={lstChecked}
          handleSelect={selectRecord}
          paging={paging}
          setIndexPage={(e) => setOffset(e)}
          selectAll={selectAll}
          selectedAllData={selectedAll}
        />)
      case TYPE_DISPLAY.table:
        return (<Table
          setIndexPage={(e) => setOffset(e)}
          data={data}
          lstChecked={lstChecked}
          handleSelect={selectRecord}
          paging={paging}
          selectAll={selectAll}
          selectedAllData={selectedAll}
        />)
      default:
        break;
    }
  }

  return (<>
    <div className="container-fluid">
      <div className="d-sm-flex justify-content-between align-items-center mb-4">
        <h3 className="text-dark mb-0">To Do {display}</h3>
        <div className="d-flex">
          <div className="mr-4 border border-primary p-2 rounded">
            <a className={`btn btn-${display === TYPE_DISPLAY.table ? "primary" : "secondary"} btn-sm d-none d-sm-inline-block mr-1`} onClick={() => changeMode(TYPE_DISPLAY.table)}>
              <i className="fas fa-table fa-sm text-white-50 p-1"></i>
            </a>
            <a className={`btn btn-${display === TYPE_DISPLAY.card ? "primary" : "secondary"} btn-sm d-none d-sm-inline-block mr-1`} onClick={() => changeMode(TYPE_DISPLAY.card)}>
              <i className="fas fa-id-card fa-sm text-white-50"></i>
            </a>
            <a className={`btn btn-${display === TYPE_DISPLAY.list ? "primary" : "secondary"} btn-sm d-none d-sm-inline-block mr-1`} onClick={() => changeMode(TYPE_DISPLAY.list)}>
              <i className="fas fa-clipboard-list fa-sm text-white-50 p-1"></i>
            </a>
          </div>
          <div className="p-2">
            <a className="btn btn-primary btn-sm d-none d-sm-inline-block" >
              <i className="fas fa-minus fa-sm text-white-50 mr-1" />
              Delete
            </a>
          </div>
        </div>
      </div>
      {renderDisplay()}
    </div>
  </>
  );
};

export default Home;

import axios, { AxiosResponse } from 'axios';
import { Storage } from 'react-jhipster';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import { AppThunk } from 'app/config/store';

const AUTH_TOKEN_KEY = 'jhi-authenticationToken';

export const initialState = {
  loading: false,
  dataList: null,
  querySearch: ""
};

export type HomeState = Readonly<typeof initialState>;

// Actions


export const getListToDo = createAsyncThunk('home/get_data_todo', async () => axios.get<any>('api/account'));


export const setQuerySearch = q => dispatch => {
  dispatch(saveQuerySearch(q));
};


export const HomeSlice = createSlice({
  name: 'home',
  initialState: initialState as HomeState,
  reducers: {
    saveQuerySearch(state, action) {
      return {
        ...state,
        querySearch: action.payload
      };
    }
  },
  extraReducers(builder) {
    builder
      .addCase(getListToDo.pending, (state, action) => ({
        ...state,
        loading: true
      }))
      .addCase(getListToDo.rejected, (state, action) => ({
        ...state,
        loading: false,
      }))
      .addCase(getListToDo.fulfilled, (state, action) => {
        const data = action.payload;
        return {
          ...state,
          loading: false,
        };
      })
  },
});

export const { saveQuerySearch, } = HomeSlice.actions;

// Reducer
export default HomeSlice.reducer;

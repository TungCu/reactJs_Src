/* eslint-disable no-console */
import { motion } from "framer-motion";

import React, { useEffect, useState } from 'react';

import { useAppSelector } from 'app/config/store';
import _ from "lodash";
import { Paging } from "./home";

export interface IList {
  data: any,
  lstChecked: any,
  handleSelect?: (d: any) => void,
  paging: Paging
}

export const List = (props: IList) => {
  const setting = useAppSelector(state => state.authentication);
  console.log(props.data)

  if (props.data) {
    return (<>
      <div className="row">
        <div className="col-lg-6 mb-4">
          <div className="card shadow mb-4"></div>
          <div className="card shadow mb-4">
            <div className="card-header py-3">
              <h6 className="text-primary font-weight-bold m-0">Todo List</h6>
            </div>
            <ul className="list-group list-group-flush">
              {
                props.data && props.data.length > 0 && props.data.map((e, i) => {
                  return (
                    <>
                      <li className="list-group-item">
                        <div className="row align-items-center no-gutters">
                          <div className="col mr-2">
                            <h6 className="mb-0">
                              <strong>{e.title}</strong>
                            </h6>
                            <span className="text-xs">{e.reminder_datetime}</span>
                          </div>
                          <div className="col-auto">
                            <div className="custom-control custom-checkbox" onClick={() => { props.handleSelect && props.handleSelect(e) }}>
                              <input className="custom-control-input"
                                type="checkbox"
                                id={e.id}
                                name={e.id}
                                value={e.id}
                                checked={props.lstChecked && Array.isArray(props.lstChecked) && props.lstChecked.find(ele => ele === e.id)}
                              />
                              <label className="custom-control-label" />
                            </div>
                          </div>
                        </div>
                      </li>
                    </>
                  )
                })
              }
            </ul>
          </div>
        </div>
        <div className="col">
          <div className="row">
            <div className="col-lg-6 mb-4">
              <div className="card text-white bg-primary shadow">
                <div className="card-body">
                  <p className="m-0">Not Yet</p>
                  <p className="text-white-50 small m-0">#4e73df</p>
                </div>
              </div>
            </div>
            <div className="col-lg-6 mb-4">
              <div className="card text-white bg-success shadow">
                <div className="card-body">
                  <p className="m-0">Doing</p>
                  <p className="text-white-50 small m-0">#1cc88a</p>
                </div>
              </div>
            </div>
            <div className="col-lg-6 mb-4">
              <div className="card text-white bg-info shadow">
                <div className="card-body">
                  <p className="m-0">Done</p>
                  <p className="text-white-50 small m-0">#36b9cc</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
    );
  } else {
    return <></>
  }
};

export default List;

# Central configuration sources details
